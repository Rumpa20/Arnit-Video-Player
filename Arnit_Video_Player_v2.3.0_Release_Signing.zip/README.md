# Arnit Video Player v1.7

Cinematic Purple Android video player project.

## Build
- Android Gradle Plugin 9.0.1 with built-in Kotlin
- Compose compiler plugin 2.2.10
- Gradle wrapper 9.1.0
- JDK 17, compileSdk 36, targetSdk 35, minSdk 24
- Media3 1.8.0

## v1.7 changes
- Multi-band equalizer UI: uses the number of bands exposed by the device Equalizer effect (commonly five), with per-band gain sliders and Bass Boost.
- Fullscreen vertical gestures are split: left half adjusts app-window brightness, right half adjusts media volume. Horizontal gestures seek by 10 seconds.
- Brightness is restored when leaving the fullscreen player.
- Subtitle vertical position setting added and saved with subtitle size and color.
- Retains v1.6: folder filtering, sleep timer, subtitle text style, search, favorites, recent history, PiP, background playback and fullscreen landscape.

## Chromecast status
The Cast SDK dependency remains in the project, but full media casting is not enabled. A Google Cast Receiver App ID and Cast session-to-player integration are required. Do not treat the Cast setup information as working casting.

## Build in CodeOnTheGo
1. Extract this ZIP into a NEW folder.
2. Open the extracted project as an existing Gradle project.
3. Allow Gradle Sync to finish.
4. Run `:app:assembleDebug`.
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This source has not been compiled in CodeOnTheGo or tested on the target phone.
- Equalizer band count and Bass Boost support depend on the Android device audio effects.
- Brightness gesture changes this app window's brightness only and restores the previous value when fullscreen closes.
- Subtitle position affects Media3 PlayerView captions; it does not alter external subtitle file timestamps.


## v1.8.1 startup hotfix

This hotfix is based on the previously prepared v1.7 project and temporarily disables the new Google Cast startup registration and native Cast route button that were introduced in v1.8.0. The existing informational Cast button remains. Other v1.7 features are retained. This is a source-level rollback/hotfix and has not been compiled or runtime-tested in this environment. Chromecast device discovery and playback are deferred until the crash is diagnosed and the Cast integration can be tested safely.


## v1.8.2 Bottom Gesture HUD

Shows a temporary bottom-center brightness or volume indicator with percentage and progress bar while vertical gestures are used in fullscreen playback. This source ZIP has not been compiled or tested on a device in this environment.


## v1.9.0 Premium Upgrade

- Added an in-player audio-track selection dialog using Media3's audio track selector.
- Added automatic next-video playback when a library video finishes, following the scanned library order.
- Retained existing playback speed controls, fullscreen screen lock, resume-from-history, and bottom brightness/volume HUD.
- Auto-next applies to videos present in the scanned library. A standalone file opened from the picker that is not in the scanned library has no next item.
- Source ZIP and AndroidManifest XML were validated. This archive has not been compiled or runtime-tested on a device.


## v2.0.0 Ultimate Edition

- Library playback now builds a queue from the scanned video library, starting at the selected video.
- Added an in-player queue dialog with direct jump-to-video selection.
- Added Repeat Off / Repeat All / Repeat One and Shuffle controls.
- Added embedded subtitle-track selection alongside the existing audio-track selector.
- Added aspect-ratio modes: Fit, Fill, Zoom, Fixed Width, and Fixed Height.
- Playback speed, repeat mode, shuffle, and aspect-ratio preferences are saved.
- Existing fullscreen lock, brightness/volume HUD, smart resume, equalizer, sleep timer, and library features are retained.
- This is a source ZIP. It has been ZIP/XML validated but has not been compiled or tested on a physical Android device in this environment.


## v2.0.1 Empty Player UI
- Branded fullscreen empty state when no video is selected.
- Shows ARNIT CINEMA, play icon and "Choose a video to begin".
- Hides playback-only controls until a video is loaded; keeps exit fullscreen.
- Retains v2.0.0 features.
- ZIP and Manifest XML validated; Android build/runtime test not performed here.


## v2.0.2 Audio Track Fix

- Replaced the Audio Track button's external TrackSelectionDialogBuilder call with an in-app Compose selector.
- The selector lists supported audio tracks with language, codec and channel details.
- Added Auto select to clear manual audio overrides and return to Media3 automatic selection.
- If no selectable audio track exists, the dialog now explains why instead of appearing to do nothing.
- Retains v2.0.1 empty fullscreen state and all v2.0.0 features.
- ZIP integrity and AndroidManifest XML validated. Android compilation and playback testing have not been performed in this environment.


## v2.1.0 Gesture & Subtitle Upgrade

- Added double-tap seek in fullscreen: double-tap left side to rewind 10 seconds; right side to forward 10 seconds.
- Added temporary on-screen seek feedback (+10 seconds / -10 seconds).
- Preserved vertical swipe brightness/volume controls and horizontal swipe seeking.
- Retained external subtitle file picker, embedded subtitle track selector, subtitle appearance settings, audio track selector, playlist queue, repeat, shuffle, aspect ratio and playback speed preferences.
- Chromecast device discovery and receiver playback are not enabled in this build; they require a separately tested Cast sender integration and an available Cast receiver.
- ZIP integrity and AndroidManifest XML validated. Android compilation and device testing have not been performed in this environment.


## v2.1.1 Full-screen Library Scroll
- Home screen and video library now use one continuous vertical scroll.
- Replaced nested lazy video lists with regular rows to prevent nested-scroll conflicts.
- Preserved two-column video cards.
- Increased thumbnail height and improved filename size, spacing and wrapping.
- Retained all v2.1.0 playback features.
- ZIP integrity and Manifest XML validated; Android compilation/runtime testing not performed here.


## v2.2.1 Grid/List View & Logo Syntax Fix
- Rebuilt from the known-good v2.1.1 source to avoid the malformed Kotlin braces in v2.2.0.
- Added persistent Grid/List view switch, two-column grid, and detailed list rows.
- Enlarged ARNIT brand icon and wordmark with a purple gradient tile.
- Retained full-page scrolling and previous playback features.
- ZIP integrity and Manifest XML validated. Android compilation/device testing not performed here.


## v2.2.2 Missing Brace Fix
- Fixed the missing closing brace at the end of the VideoCard composable.
- This restores FullscreenPlayer and subsequent composables as top-level declarations.
- Retains Grid/List switch, persistent view preference, prominent ARNIT logo and previous player features.
- ZIP integrity and AndroidManifest XML validated. Android compilation/device testing have not been performed in this environment.


## v2.3.0 Ultimate Library
- Added multi-select mode for Grid and List views, with select all and deselect/cancel.
- Added multi-video sharing through Android Sharesheet.
- Added video details for selected item: folder, duration, size, format and URI.
- Added confirmed bulk deletion through Android MediaStore system approval on Android 11+.
- Added Oldest, Shortest and Smallest sorting options alongside Newest, Name, Longest and Largest.
- Existing playback, Grid/List preference, prominent logo and scrolling retained.
- ZIP integrity and Manifest XML validated. Android compilation and device testing have not been performed in this environment.
