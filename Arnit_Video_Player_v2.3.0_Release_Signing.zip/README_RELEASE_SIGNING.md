# Arnit Video Player v2.3.0 - Release signing

This is a source project, not a prebuilt APK. Android compilation and device testing
must be completed in CodeOnTheGo before publishing.

## 1. Create a NEW private release keystore on your phone

Use Termux. Keep the keystore outside the project folder and make a secure backup.
Do not share the keystore or passwords in chat or screenshots.

Example command (it prompts you to enter passwords privately):

    keytool -genkeypair -v -keystore ~/arnit-video-release.jks -alias arnitvideo -keyalg RSA -keysize 2048 -validity 10000 -storetype JKS

If `keytool` is not found, install/use a JDK 17 environment in Termux or the keytool
provided by your Android development environment. Do not paste passwords into a
shared terminal screenshot.

## 2. Configure signing

1. Copy `keystore.properties.example` to `keystore.properties` in the project root.
2. Set `storeFile` to the actual keystore path. If you keep the keystore in the
   project root, use `arnit-video-release.jks`; if you keep it one folder above
   the project, use `../arnit-video-release.jks`.
3. Fill in `storePassword`, `keyAlias`, and `keyPassword`.
4. Never include `keystore.properties` or the `.jks` file in a ZIP or upload.

## 3. Build in CodeOnTheGo

1. Open this extracted project as an existing Gradle project.
2. Confirm JDK 17 is selected.
3. Let Gradle sync finish using the wrapper.
4. Run the Gradle task `:app:assembleRelease`.

Expected output:

    app/build/outputs/apk/release/app-release.apk

If Gradle reports that signing values are missing, check that `keystore.properties`
is in the project root and the `storeFile` path is correct.

## 4. Verify before publishing

- Install the release APK on your phone.
- Test library scan, Grid/List, multi-select, share, details, sorting, playback,
  subtitles, audio tracks, PiP and bulk-delete confirmation.
- Confirm the app launches and plays local videos.
- Keep the keystore and passwords backed up securely. Losing them can prevent
  signing future updates with the same app identity.

This project ZIP has not been compiled in this environment. A successful APK build
and device test must be confirmed on your phone.
