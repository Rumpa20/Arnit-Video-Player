package com.arnit.videoplayer

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Rational
import android.util.LruCache
import android.view.WindowManager
import android.util.TypedValue
import androidx.media3.ui.CaptionStyleCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyListItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import androidx.media3.ui.TrackSelectionDialogBuilder
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay


private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private val Purple = Color(0xFF7541D8)
private val PurpleBright = Color(0xFF9B6DFF)
private val LightBackground = Color(0xFFF5F1FB)
private val DarkBackground = Color(0xFF100B19)

data class VideoEntry(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val folder: String
)

data class HistoryEntry(
    val uri: Uri,
    val name: String,
    val positionMs: Long,
    val playedAt: Long
)

private val thumbnailCache = LruCache<String, Bitmap>(24)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private var oldOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    private fun requestFullscreenLandscape(enabled: Boolean) {
        if (enabled) {
            oldOrientation = requestedOrientation
            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            requestedOrientation = oldOrientation
            oldOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            mediaController = controllerFuture?.get()
            setContent {
                ArnitApp(
                    mediaController,
                    onPip = { enterPip() },
                    onFullscreenChanged = { requestFullscreenLandscape(it) }
                )
            }
        }, { command -> command.run() })
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9)).build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        super.onDestroy()
    }
}

private fun requiredVideoPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private suspend fun scanVideos(context: Context): List<VideoEntry> = withContext(Dispatchers.IO) {
    val result = mutableListOf<VideoEntry>()
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.BUCKET_DISPLAY_NAME
    )
    val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
    runCatching {
        context.contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val folderCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                result += VideoEntry(
                    uri = uri,
                    name = cursor.getString(nameCol) ?: "Video",
                    durationMs = cursor.getLong(durationCol),
                    sizeBytes = cursor.getLong(sizeCol),
                    folder = if (folderCol >= 0) cursor.getString(folderCol) ?: "Unknown folder" else "Unknown folder"
                )
            }
        }
    }
    result
}

private fun formatDuration(ms: Long): String {
    val total = (ms / 1000).toInt()
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private suspend fun loadThumb(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
    val key = uri.toString()
    thumbnailCache.get(key)?.let { return@withContext it }
    val bitmap = runCatching {
        if (Build.VERSION.SDK_INT >= 29) {
            context.contentResolver.loadThumbnail(uri, android.util.Size(320, 180), null)
        } else {
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        }
    }.getOrNull()
    if (bitmap != null) thumbnailCache.put(key, bitmap)
    bitmap
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun ArnitApp(
    player: MediaController?,
    onPip: () -> Unit,
    onFullscreenChanged: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    // Light mode is intentionally the default on first launch.
    val settings = remember { context.getSharedPreferences("arnit_player_settings", Context.MODE_PRIVATE) }
    var darkMode by remember { mutableStateOf(settings.getBoolean("dark_mode", false)) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    var isBuffering by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    var showUrl by remember { mutableStateOf(false) }
    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    var currentTitle by remember { mutableStateOf("Choose a video to begin") }
    var videos by remember { mutableStateOf<List<VideoEntry>>(emptyList()) }
    var scanMessage by remember { mutableStateOf("Scan your device to find videos") }
    var fullScreen by remember { mutableStateOf(false) }
    var wallpaperUri by remember {
        mutableStateOf(settings.getString("wallpaper_uri", null)?.let { runCatching { Uri.parse(it) }.getOrNull() })
    }
    var history by remember { mutableStateOf<List<HistoryEntry>>(emptyList()) }
    var selectedTab by remember { mutableStateOf("All videos") }
    var searchQuery by remember { mutableStateOf("") }
    var sortBy by remember { mutableStateOf("Newest") }
    var libraryView by remember { mutableStateOf(settings.getString("library_view", "Grid") ?: "Grid") }
    var selectionMode by remember { mutableStateOf(false) }
    var selectedVideoUris by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showVideoDetails by remember { mutableStateOf<VideoEntry?>(null) }
    var showSortMenu by remember { mutableStateOf(false) }
    var selectedFolder by remember { mutableStateOf("All folders") }
    var showFolderMenu by remember { mutableStateOf(false) }
    var showEqualizer by remember { mutableStateOf(false) }
    var showSleepTimer by remember { mutableStateOf(false) }
    var showCastInfo by remember { mutableStateOf(false) }
    var showSubtitleSettings by remember { mutableStateOf(false) }
    var subtitleSizeSp by remember { mutableFloatStateOf(settings.getFloat("subtitle_size", 20f)) }
    var subtitleColorName by remember { mutableStateOf(settings.getString("subtitle_color", "White") ?: "White") }
    var subtitleBottomPadding by remember { mutableFloatStateOf(settings.getFloat("subtitle_position", 0.08f)) }
    var sleepTimerMinutes by remember { mutableStateOf(0) }
    var favorites by remember {
        mutableStateOf(settings.getStringSet("favorite_uris", emptySet()).orEmpty().toSet())
    }
    fun toggleFavorite(uri: Uri) {
        val key = uri.toString()
        favorites = if (key in favorites) favorites - key else favorites + key
        settings.edit().putStringSet("favorite_uris", favorites.toSet()).apply()
    }
    var permissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, requiredVideoPermission()) == PackageManager.PERMISSION_GRANTED)
    }

    fun loadHistory(): List<HistoryEntry> {
        return settings.getStringSet("play_history", emptySet()).orEmpty().mapNotNull { row ->
            val parts = row.split("|||", limit = 4)
            if (parts.size != 4) null else runCatching {
                HistoryEntry(Uri.parse(parts[0]), parts[1], parts[2].toLong(), parts[3].toLong())
            }.getOrNull()
        }.sortedByDescending { it.playedAt }
    }

    fun saveHistory(uri: Uri, title: String, positionMs: Long) {
        val updated = (listOf(HistoryEntry(uri, title, positionMs, System.currentTimeMillis())) +
            history.filterNot { it.uri == uri }).take(60)
        history = updated
        settings.edit().putStringSet(
            "play_history",
            updated.map { "${it.uri}|||${it.name}|||${it.positionMs}|||${it.playedAt}" }.toSet()
        ).apply()
    }

    val currentTitleLatest by rememberUpdatedState(currentTitle)
    val videosLatest by rememberUpdatedState(videos)
    val setCurrentTitleLatest by rememberUpdatedState<(String) -> Unit> { nextTitle ->
        currentTitle = nextTitle
    }
    val saveHistoryLatest by rememberUpdatedState(
        newValue = { uri: Uri, title: String, positionMs: Long ->
            saveHistory(uri, title, positionMs)
        }
    )

    fun buildMediaItem(videoUri: Uri): MediaItem {
        val builder = MediaItem.Builder().setUri(videoUri)
        subtitleUri?.let { subUri ->
            builder.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(subUri)
                        .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                        .setLanguage("en")
                        .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        return builder.build()
    }

    fun playVideo(uri: Uri, title: String) {
        playbackError = null
        runCatching {
            val savedPosition = history.firstOrNull { it.uri == uri }?.positionMs ?: 0L
            val libraryQueue = videos
            val startIndex = libraryQueue.indexOfFirst { it.uri == uri }
            if (startIndex >= 0 && libraryQueue.isNotEmpty()) {
                val queueItems = libraryQueue.map { buildMediaItem(it.uri) }
                player?.setMediaItems(queueItems, startIndex, savedPosition.coerceAtLeast(0L))
            } else {
                player?.setMediaItem(buildMediaItem(uri))
                if (savedPosition > 1500L) player?.seekTo(savedPosition)
            }
            player?.prepare()
            player?.play()
            currentTitle = title
            saveHistory(uri, title, savedPosition)
        }.onFailure {
            playbackError = it.localizedMessage ?: "Unable to open this video"
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) {
            scope.launch {
                val found = scanVideos(context)
                videos = found
                scanMessage = if (found.isEmpty()) "No videos found on this device" else "${found.size} videos found"
            }
        } else {
            scanMessage = "Video permission is needed to scan your library"
        }
    }
    val deleteVideosLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            selectedVideoUris = emptySet()
            selectionMode = false
            scope.launch {
                videos = scanVideos(context)
                scanMessage = "${videos.size} videos found"
            }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            playVideo(uri, uri.lastPathSegment?.substringAfterLast('/') ?: "Local video")
        }
    }
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            subtitleUri = uri
            val activeUri = player?.currentMediaItem?.localConfiguration?.uri
            if (activeUri != null) playVideo(activeUri, currentTitle)
        }
    }
    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            wallpaperUri = uri
            settings.edit().putString("wallpaper_uri", uri.toString()).apply()
        }
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                playbackError = error.localizedMessage ?: "Playback failed. Check the file or network."
                isBuffering = false
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) playbackError = null
                if (playbackState == Player.STATE_ENDED) {
                    val playlist = videosLatest
                    val endedUri = player.currentMediaItem?.localConfiguration?.uri
                    val endedIndex = playlist.indexOfFirst { it.uri == endedUri }
                    val nextVideo = playlist.getOrNull(endedIndex + 1)
                    if (endedIndex >= 0 && nextVideo != null) {
                        runCatching {
                            player.setMediaItem(buildMediaItem(nextVideo.uri))
                            player.prepare()
                            player.play()
                            setCurrentTitleLatest(nextVideo.name)
                            saveHistoryLatest(nextVideo.uri, nextVideo.name, 0L)
                        }.onFailure {
                            playbackError = it.localizedMessage ?: "Unable to play next video"
                        }
                    }
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                val uri = player.currentMediaItem?.localConfiguration?.uri
                if (!isPlaying && uri != null) saveHistoryLatest(uri, currentTitleLatest, player.currentPosition)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(Unit) {
        history = loadHistory()
        if (permissionGranted) {
            videos = scanVideos(context)
            scanMessage = if (videos.isEmpty()) "No videos found on this device" else "${videos.size} videos found"
        } else {
            permissionLauncher.launch(requiredVideoPermission())
        }
    }

    LaunchedEffect(player) {
        while (true) {
            delay(4000)
            if (player != null && player.currentMediaItem != null) {
                val uri = player.currentMediaItem?.localConfiguration?.uri
                if (uri != null) saveHistoryLatest(uri, currentTitleLatest, player.currentPosition)
            }
        }
    }

    LaunchedEffect(sleepTimerMinutes, player) {
        if (sleepTimerMinutes > 0) {
            delay(sleepTimerMinutes * 60_000L)
            player?.pause()
            sleepTimerMinutes = 0
        }
    }

    LaunchedEffect(fullScreen) { onFullscreenChanged(fullScreen) }

    val bg = if (darkMode) DarkBackground else LightBackground
    val fg = if (darkMode) Color.White else Color(0xFF241B30)
    val card = if (darkMode) Color(0xFF21182D) else Color.White
    val wallpaper by produceState<Bitmap?>(initialValue = null, wallpaperUri) {
        value = wallpaperUri?.let { loadThumb(context, it) }
    }

    MaterialTheme(
        colorScheme = if (darkMode) darkColorScheme(primary = PurpleBright, background = bg, surface = card)
        else lightColorScheme(primary = Purple, background = bg, surface = card)
    ) {
        Scaffold(
            containerColor = bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp))
                                    .background(Brush.linearGradient(listOf(Color(0xFFB58AFF), Color(0xFF7541D8)))),
                                    contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PlayCircleFilled, null, tint = Color.White, modifier = Modifier.size(30.dp))
                                }
                                Spacer(Modifier.width(9.dp))
                                Text("ARNIT", fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.5.sp, color = PurpleBright)
                            }
                            Text("VIDEO PLAYER", fontSize = 10.sp, letterSpacing = 2.4.sp, color = fg.copy(alpha = .78f), fontWeight = FontWeight.SemiBold)
                        }
                    },
                    actions = {
                        TextButton(onClick = { wallpaperPicker.launch(arrayOf("image/*")) }) {
                            Icon(Icons.Default.Wallpaper, "Choose background", tint = fg)
                            Spacer(Modifier.width(3.dp))
                            Text("Background")
                        }
                        if (wallpaperUri != null) {
                            IconButton(onClick = {
                                wallpaperUri = null
                                settings.edit().remove("wallpaper_uri").apply()
                            }) {
                                Icon(Icons.Default.Close, "Reset background", tint = fg)
                            }
                        }
                        IconButton(onClick = {
                            darkMode = !darkMode
                            settings.edit().putBoolean("dark_mode", darkMode).apply()
                        }) {
                            Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme", tint = fg)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = bg)
                )
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(22.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF28143F), Color(0xFF100B19), Color(0xFF4C247A)))),
                    contentAlignment = Alignment.Center
                ) {
                    if (wallpaper != null) {
                        Image(
                            bitmap = wallpaper!!.asImageBitmap(),
                            contentDescription = "Custom background",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            alpha = 0.42f
                        )
                    }
                    if (player != null && player.currentMediaItem != null) {
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).apply {
                                this.player = player
                                useController = true
                                controllerAutoShow = true
                                controllerShowTimeoutMs = 3500
                                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                                resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                                applySubtitleStyle(this, subtitleSizeSp, subtitleColorName, subtitleBottomPadding)
                            } },
                            update = { view ->
                                view.player = player
                                applySubtitleStyle(view, subtitleSizeSp, subtitleColorName, subtitleBottomPadding)
                                view.useController = true
                                view.controllerAutoShow = true
                                view.controllerShowTimeoutMs = 3500
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        if (isBuffering) {
                            CircularProgressIndicator(color = PurpleBright, modifier = Modifier.align(Alignment.Center))
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PlayCircle, null, tint = PurpleBright, modifier = Modifier.size(64.dp))
                            Text("ARNIT CINEMA", color = Color.White, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Text(currentTitle, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                playbackError?.let { message ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (darkMode) Color(0xFF3A2028) else Color(0xFFFFE8EC)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ErrorOutline, null, tint = Color(0xFFD94B65))
                            Spacer(Modifier.width(8.dp))
                            Text(message, color = fg, modifier = Modifier.weight(1f), fontSize = 12.sp)
                            TextButton(onClick = {
                                playbackError = null
                                runCatching { player?.prepare(); player?.play() }
                            }) { Text("Retry") }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { videoPicker.launch(arrayOf("video/*")) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(5.dp)); Text("Open Video")
                    }
                    OutlinedButton(onClick = { showUrl = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Link, null); Spacer(Modifier.width(5.dp)); Text("Stream URL")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { subtitlePicker.launch(arrayOf("text/*", "application/x-subrip", "application/octet-stream")) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Subtitles, null); Spacer(Modifier.width(4.dp)); Text("Subtitle")
                    }
                    OutlinedButton(onClick = onPip, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.PictureInPictureAlt, null); Spacer(Modifier.width(4.dp)); Text("PiP")
                    }
                    OutlinedButton(onClick = { fullScreen = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Fullscreen, null); Spacer(Modifier.width(4.dp)); Text("Full")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { showEqualizer = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Default.Equalizer, null); Spacer(Modifier.width(3.dp)); Text("EQ", maxLines = 1)
                    }
                    OutlinedButton(onClick = { showSubtitleSettings = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Default.TextFields, null); Spacer(Modifier.width(3.dp)); Text("Subs", maxLines = 1)
                    }
                    OutlinedButton(onClick = { showSleepTimer = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Default.Timer, null); Spacer(Modifier.width(3.dp)); Text("Sleep", maxLines = 1)
                    }
                    OutlinedButton(onClick = { showCastInfo = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Default.Cast, null); Spacer(Modifier.width(3.dp)); Text("Cast", maxLines = 1)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("VIDEO LIBRARY", color = PurpleBright, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                        Text(scanMessage, color = fg.copy(alpha = .65f), fontSize = 11.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            libraryView = "Grid"
                            settings.edit().putString("library_view", libraryView).apply()
                        }, modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (libraryView == "Grid") Purple.copy(alpha = .15f) else Color.Transparent)) {
                            Icon(Icons.Default.GridView, "Grid view", tint = if (libraryView == "Grid") PurpleBright else fg.copy(alpha = .65f))
                        }
                        IconButton(onClick = {
                            libraryView = "List"
                            settings.edit().putString("library_view", libraryView).apply()
                        }, modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (libraryView == "List") Purple.copy(alpha = .15f) else Color.Transparent)) {
                            Icon(Icons.Default.ViewList, "List view", tint = if (libraryView == "List") PurpleBright else fg.copy(alpha = .65f))
                        }
                    }
                    OutlinedButton(onClick = {
                        if (permissionGranted) {
                            scope.launch {
                                scanMessage = "Scanning videos..."
                                val found = scanVideos(context)
                                videos = found
                                scanMessage = if (found.isEmpty()) "No videos found on this device" else "${found.size} videos found"
                            }
                        } else permissionLauncher.launch(requiredVideoPermission())
                    }) {
                        Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Scan")
                    }
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search videos by name") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search")
                        }
                    }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(selected = selectedTab == "All videos", onClick = { selectedTab = "All videos" }, label = { Text("All") })
                    FilterChip(selected = selectedTab == "Recent", onClick = { selectedTab = "Recent" }, label = { Text("Recent") })
                    FilterChip(selected = selectedTab == "Favorites", onClick = { selectedTab = "Favorites" }, label = { Text("Favorites") })
                    Spacer(Modifier.weight(1f))
                    Box {
                        TextButton(onClick = { showSortMenu = true }) {
                            Icon(Icons.Default.Sort, contentDescription = null)
                            Text(sortBy, maxLines = 1)
                        }
                        DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                            listOf("Newest", "Oldest", "Name", "Longest", "Shortest", "Largest", "Smallest").forEach { option ->
                                DropdownMenuItem(text = { Text(option) }, onClick = {
                                    sortBy = option
                                    showSortMenu = false
                                })
                            }
                        }
                    }
                }

                if (selectedTab != "Recent") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TextButton(onClick = {
                            selectionMode = !selectionMode
                            selectedVideoUris = emptySet()
                        }) {
                            Icon(if (selectionMode) Icons.Default.Close else Icons.Default.Checklist, null)
                            Spacer(Modifier.width(4.dp))
                            Text(if (selectionMode) "Cancel" else "Select")
                        }
                        if (selectionMode) {
                            Text("${selectedVideoUris.size} selected", color = PurpleBright, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = {
                                val visible = videos.filter { it.uri.toString() in selectedVideoUris }.map { it.uri }
                                selectedVideoUris = if (visible.size == videos.size) emptySet() else videos.map { it.uri.toString() }.toSet()
                            }) { Text(if (selectedVideoUris.size == videos.size) "Deselect all" else "Select all") }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Folder:", color = fg.copy(alpha = .7f), fontSize = 12.sp)
                        Spacer(Modifier.width(8.dp))
                        Box {
                            OutlinedButton(onClick = { showFolderMenu = true }) {
                                Icon(Icons.Default.FolderOpen, null)
                                Spacer(Modifier.width(5.dp))
                                Text(selectedFolder, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            DropdownMenu(expanded = showFolderMenu, onDismissRequest = { showFolderMenu = false }) {
                                val folders = listOf("All folders") + videos.map { it.folder }.distinct().sorted()
                                folders.forEach { folder ->
                                    DropdownMenuItem(
                                        text = { Text(folder) },
                                        onClick = { selectedFolder = folder; showFolderMenu = false }
                                    )
                                }
                            }
                        }
                    }
                }

                if (selectionMode && selectedVideoUris.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(onClick = {
                            val chosen = videos.filter { it.uri.toString() in selectedVideoUris }
                            val sendIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                type = "video/*"
                                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(chosen.map { it.uri }))
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share videos"))
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Share, null)
                            Spacer(Modifier.width(5.dp))
                            Text("Share")
                        }
                        OutlinedButton(onClick = {
                            showVideoDetails = videos.firstOrNull { it.uri.toString() in selectedVideoUris }
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Info, null)
                            Spacer(Modifier.width(5.dp))
                            Text("Details")
                        }
                        OutlinedButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Delete, null)
                            Spacer(Modifier.width(5.dp))
                            Text("Delete")
                        }
                    }
                }

                if (selectedTab == "Recent" && history.isEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = card),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.History, null, tint = PurpleBright, modifier = Modifier.size(36.dp))
                            Text("No recent videos yet", color = fg, fontWeight = FontWeight.SemiBold)
                            Text("Videos you play will appear here with Resume Playback.", color = fg.copy(alpha = .65f), fontSize = 12.sp)
                        }
                    }
                } else if (selectedTab == "Recent" && history.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        history.filter { it.name.contains(searchQuery, ignoreCase = true) }.forEach { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val saved = item.positionMs
                                    playbackError = null
                                    runCatching {
                                        player?.setMediaItem(buildMediaItem(item.uri))
                                        player?.prepare()
                                        if (saved > 1500L) player?.seekTo(saved)
                                        player?.play()
                                        currentTitle = item.name
                                    }.onFailure { playbackError = it.localizedMessage ?: "Unable to resume video" }
                                },
                                colors = CardDefaults.cardColors(containerColor = card)
                            ) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.History, null, tint = PurpleBright, modifier = Modifier.size(30.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name, color = fg, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                        Text("Resume at ${formatDuration(item.positionMs)}", color = fg.copy(alpha = .65f), fontSize = 11.sp)
                                    }
                                    Icon(Icons.Default.PlayArrow, null, tint = PurpleBright)
                                }
                            }
                        }
                    }
                } else if (selectedTab == "Favorites" && favorites.isEmpty()) {
                    Card(colors = CardDefaults.cardColors(containerColor = card), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FavoriteBorder, null, tint = PurpleBright, modifier = Modifier.size(34.dp))
                            Text("No favourites yet", color = fg, fontWeight = FontWeight.SemiBold)
                            Text("Tap the heart on a video to save it here.", color = fg.copy(alpha = .65f), fontSize = 12.sp)
                        }
                    }
                } else if (videos.isEmpty()) {
                    Card(colors = CardDefaults.cardColors(containerColor = card), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.VideoLibrary, null, tint = PurpleBright, modifier = Modifier.size(34.dp))
                            Text("Your videos will appear here", color = fg, fontWeight = FontWeight.SemiBold)
                            Text("Tap Scan or Open Video to get started.", color = fg.copy(alpha = .65f), fontSize = 12.sp)
                        }
                    }
                } else if (selectedTab != "Recent" || history.isEmpty()) {
                    val baseVideos = if (selectedTab == "Favorites") videos.filter { it.uri.toString() in favorites } else videos
                    val folderVideos = if (selectedFolder == "All folders") baseVideos else baseVideos.filter { it.folder == selectedFolder }
                    val matchingVideos = folderVideos.filter { it.name.contains(searchQuery, ignoreCase = true) }
                    val shownVideos = when (sortBy) {
                        "Name" -> matchingVideos.sortedBy { it.name.lowercase() }
                        "Oldest" -> matchingVideos.reversed()
                        "Longest" -> matchingVideos.sortedByDescending { it.durationMs }
                        "Shortest" -> matchingVideos.sortedBy { it.durationMs }
                        "Largest" -> matchingVideos.sortedByDescending { it.sizeBytes }
                        "Smallest" -> matchingVideos.sortedBy { it.sizeBytes }
                        else -> matchingVideos
                    }
                    if (libraryView == "Grid") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            shownVideos.chunked(2).forEach { rowVideos ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    rowVideos.forEach { video ->
                                        Box(Modifier.weight(1f)) {
                                            VideoCard(video, card, fg, context,
                                                video.uri.toString() in favorites, false,
                                                video.uri.toString() in selectedVideoUris,
                                                selectionMode,
                                                { toggleFavorite(video.uri) },
                                                { selectedVideoUris = if (video.uri.toString() in selectedVideoUris) selectedVideoUris - video.uri.toString() else selectedVideoUris + video.uri.toString() },
                                                { if (selectionMode) selectedVideoUris = selectedVideoUris + video.uri.toString() else playVideo(video.uri, video.name) })
                                        }
                                    }
                                    if (rowVideos.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            shownVideos.forEach { video ->
                                VideoCard(video, card, fg, context,
                                    video.uri.toString() in favorites, true,
                                    video.uri.toString() in selectedVideoUris,
                                    selectionMode,
                                    { toggleFavorite(video.uri) },
                                    { selectedVideoUris = if (video.uri.toString() in selectedVideoUris) selectedVideoUris - video.uri.toString() else selectedVideoUris + video.uri.toString() },
                                    { if (selectionMode) selectedVideoUris = selectedVideoUris + video.uri.toString() else playVideo(video.uri, video.name) })
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete selected videos?") },
            text = {
                Text("You selected ${selectedVideoUris.size} video(s). Android will ask you to confirm deletion. This action cannot be undone.")
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    val selectedUris = videos.filter { it.uri.toString() in selectedVideoUris }.map { it.uri }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && selectedUris.isNotEmpty()) {
                        runCatching {
                            val request = MediaStore.createDeleteRequest(context.contentResolver, selectedUris)
                            deleteVideosLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                        }.onFailure { playbackError = it.localizedMessage ?: "Unable to request video deletion" }
                    } else {
                        playbackError = "Bulk delete requires Android 11 or newer. You can delete videos using your device's Gallery app."
                    }
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") } }
        )
    }

    showVideoDetails?.let { item ->
        AlertDialog(
            onDismissRequest = { showVideoDetails = null },
            title = { Text("Video details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(item.name, fontWeight = FontWeight.SemiBold)
                    Text("Folder: ${item.folder}")
                    Text("Duration: ${formatDuration(item.durationMs)}")
                    Text("File size: ${String.format(java.util.Locale.getDefault(), "%.1f MB", item.sizeBytes / (1024f * 1024f))}")
                    Text("Format: ${item.name.substringAfterLast('.', "Unknown").uppercase()}")
                    Text("Location: ${item.uri}", style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            },
            confirmButton = { TextButton(onClick = { showVideoDetails = null }) { Text("Close") } }
        )
    }

    if (showSubtitleSettings) {
        AlertDialog(
            onDismissRequest = { showSubtitleSettings = false },
            title = { Text("Subtitle appearance") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Text size: ${subtitleSizeSp.toInt()} sp")
                    Slider(
                        value = subtitleSizeSp,
                        onValueChange = {
                            subtitleSizeSp = it
                            settings.edit().putFloat("subtitle_size", it).apply()
                        },
                        valueRange = 14f..32f
                    )
                    Text("Subtitle vertical position")
                    Slider(
                        value = subtitleBottomPadding,
                        onValueChange = {
                            subtitleBottomPadding = it
                            settings.edit().putFloat("subtitle_position", it).apply()
                        },
                        valueRange = 0.02f..0.30f
                    )
                    Text(if (subtitleBottomPadding < 0.10f) "Near bottom" else "Higher on screen")
                    Text("Text color")
                    listOf("White", "Yellow", "Cyan", "Green").forEach { color ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = subtitleColorName == color,
                                onClick = {
                                    subtitleColorName = color
                                    settings.edit().putString("subtitle_color", color).apply()
                                }
                            )
                            Text(color)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSubtitleSettings = false }) { Text("Done") } }
        )
    }

    if (showEqualizer) {
        EqualizerDialog(
            audioSessionId = PlaybackService.audioSessionId,
            onDismiss = { showEqualizer = false }
        )
    }

    if (showSleepTimer) {
        AlertDialog(
            onDismissRequest = { showSleepTimer = false },
            title = { Text("Sleep timer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pause playback automatically after:")
                    listOf(0, 15, 30, 45, 60, 90).forEach { minutes ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = sleepTimerMinutes == minutes, onClick = { sleepTimerMinutes = minutes })
                            Text(if (minutes == 0) "Off" else "$minutes minutes")
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSleepTimer = false }) { Text("Done") } }
        )
    }

    if (showCastInfo) {
        AlertDialog(
            onDismissRequest = { showCastInfo = false },
            title = { Text("Chromecast setup") },
            text = { Text("Chromecast integration is being prepared. The Cast device picker will be enabled in a later tested update. A compatible Cast device and the phone must be on the same Wi-Fi network.") },
            confirmButton = { TextButton(onClick = { showCastInfo = false }) { Text("OK") } }
        )
    }

    if (showUrl) {
        AlertDialog(
            onDismissRequest = { showUrl = false },
            title = { Text("Play online video") },
            text = {
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Video URL (HTTPS)") }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = url.trim()
                    if (clean.startsWith("https://") || clean.startsWith("http://")) {
                        playbackError = null
                        player?.setMediaItem(
                            MediaItem.Builder().setUri(clean)
                                .setMediaMetadata(MediaMetadata.Builder().setTitle("Online stream").build()).build()
                        )
                        player?.prepare()
                        player?.play()
                        currentTitle = clean.substringAfterLast('/').substringBefore('?').ifBlank { "Online stream" }
                        saveHistory(Uri.parse(clean), currentTitle, 0L)
                    } else {
                        playbackError = "Please enter a valid HTTP or HTTPS video URL."
                    }
                    showUrl = false
                }) { Text("Play") }
            },
            dismissButton = { TextButton(onClick = { showUrl = false }) { Text("Cancel") } }
        )
    }

    if (fullScreen && player != null) {
        Dialog(
            onDismissRequest = { fullScreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            FullscreenPlayer(
                player,
                onClose = { fullScreen = false },
                subtitleSizeSp = subtitleSizeSp,
                subtitleColorName = subtitleColorName,
                subtitleBottomPadding = subtitleBottomPadding
            )
        }
    }
}

private fun applySubtitleStyle(view: PlayerView, sizeSp: Float, colorName: String, bottomPadding: Float) {
    val foreground = when (colorName) {
        "Yellow" -> android.graphics.Color.YELLOW
        "Cyan" -> android.graphics.Color.CYAN
        "Green" -> android.graphics.Color.GREEN
        else -> android.graphics.Color.WHITE
    }
    view.subtitleView?.apply {
        setStyle(
            CaptionStyleCompat(
                foreground,
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                null
            )
        )
        setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setBottomPaddingFraction(bottomPadding.coerceIn(0.02f, 0.30f))
    }
}

@Composable
private fun EqualizerDialog(audioSessionId: Int, onDismiss: () -> Unit) {
    var enabled by remember { mutableStateOf(false) }
    var bassStrength by remember { mutableFloatStateOf(0.35f) }
    var status by remember { mutableStateOf("Start playback to connect audio effects.") }
    val equalizer = remember(audioSessionId) {
        runCatching { if (audioSessionId > 0) Equalizer(0, audioSessionId) else null }.getOrNull()
    }
    val bass = remember(audioSessionId) {
        runCatching { if (audioSessionId > 0) BassBoost(0, audioSessionId) else null }.getOrNull()
    }
    val bandCount = remember(equalizer) { runCatching { equalizer?.numberOfBands?.toInt() ?: 0 }.getOrDefault(0) }
    val range = remember(equalizer) {
        runCatching { equalizer?.bandLevelRange?.let { it[0].toFloat()..it[1].toFloat() } ?: (-1500f..1500f) }
            .getOrDefault(-1500f..1500f)
    }
    var bandValues by remember(equalizer) {
        mutableStateOf(
            (0 until bandCount).map { band ->
                runCatching { equalizer?.getBandLevel(band.toShort())?.toFloat() ?: 0f }.getOrDefault(0f)
            }
        )
    }
    DisposableEffect(equalizer, bass) {
        onDispose {
            runCatching { equalizer?.enabled = false; equalizer?.release() }
            runCatching { bass?.enabled = false; bass?.release() }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Arnit 5-Band Equalizer") },
        text = {
            Column(
                modifier = Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Enable audio effects", modifier = Modifier.weight(1f))
                    Switch(
                        checked = enabled,
                        onCheckedChange = { value ->
                            enabled = value
                            runCatching {
                                equalizer?.enabled = value
                                bass?.enabled = value
                            }.onFailure { status = "Device equalizer is unavailable." }
                            if (equalizer == null || bass == null) status = "Start a video first. Device audio effects may not be available."
                        }
                    )
                }
                if (bandCount > 0) {
                    Text("Frequency bands", style = MaterialTheme.typography.titleSmall)
                    val labels = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")
                    bandValues.forEachIndexed { index, value ->
                        val center = runCatching { equalizer?.getCenterFreq(index.toShort())?.div(1000f) ?: 0f }.getOrDefault(0f)
                        val label = labels.getOrNull(index) ?: "${center.toInt()} Hz"
                        Text("$label  ${value.toInt()} mB", style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = value.coerceIn(range.start, range.endInclusive),
                            onValueChange = { newValue ->
                                bandValues = bandValues.toMutableList().also { it[index] = newValue }
                                runCatching {
                                    equalizer?.setBandLevel(index.toShort(), newValue.toInt().toShort())
                                    equalizer?.enabled = enabled
                                }.onFailure { status = "Could not update this frequency band." }
                            },
                            valueRange = range
                        )
                    }
                } else {
                    Text("This device does not expose a 5-band equalizer session.")
                }
                Text("Bass boost", style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = bassStrength,
                    onValueChange = { value ->
                        bassStrength = value
                        runCatching {
                            bass?.setStrength((value * 1000).toInt().toShort())
                            bass?.enabled = enabled
                        }.onFailure { status = "Bass boost is unavailable on this device." }
                    },
                    valueRange = 0f..1f
                )
                Text("${(bassStrength * 100).toInt()}%", color = PurpleBright)
                Text(status, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun VideoCard(
    video: VideoEntry,
    cardColor: Color,
    textColor: Color,
    context: Context,
    isFavorite: Boolean,
    isListView: Boolean,
    isSelected: Boolean,
    selectionMode: Boolean,
    onToggleFavorite: () -> Unit,
    onToggleSelection: () -> Unit,
    onClick: () -> Unit
) {
    val bitmap by produceState<Bitmap?>(initialValue = null, video.uri) {
        value = loadThumb(context, video.uri)
    }
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(16.dp)) {
        if (isListView) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(112.dp).height(82.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF251535)), contentAlignment = Alignment.Center) {
                    if (bitmap != null) Image(bitmap!!.asImageBitmap(), video.name, Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                    else Icon(Icons.Default.Movie, null, tint = PurpleBright, modifier = Modifier.size(32.dp))
                    Text(formatDuration(video.durationMs), color = Color.White,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                            .background(Color.Black.copy(alpha=.72f), RoundedCornerShape(4.dp))
                            .padding(horizontal=5.dp, vertical=2.dp), fontSize=10.sp)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    Text(video.name, color=textColor, maxLines=2, overflow=TextOverflow.Ellipsis,
                        fontSize=14.sp, lineHeight=18.sp, fontWeight=FontWeight.SemiBold)
                    Text(video.folder, color=textColor.copy(alpha=.62f), maxLines=1,
                        overflow=TextOverflow.Ellipsis, fontSize=11.sp)
                    Text(String.format(java.util.Locale.getDefault(),"%.1f MB",video.sizeBytes/(1024f*1024f)),
                        color=textColor.copy(alpha=.58f), fontSize=11.sp)
                }
                if (selectionMode) {
                    Checkbox(checked = isSelected, onCheckedChange = { onToggleSelection() })
                } else {
                    IconButton(onClick=onToggleFavorite) {
                        Icon(if(isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            if(isFavorite) "Remove from favourites" else "Add to favourites",
                            tint=if(isFavorite) Color(0xFFFF5C8A) else textColor.copy(alpha=.72f))
                    }
                }
            }
        } else {
            Column {
                Box(Modifier.fillMaxWidth().height(124.dp).background(Color(0xFF251535)),
                    contentAlignment=Alignment.Center) {
                    if(bitmap!=null) Image(bitmap!!.asImageBitmap(),video.name,Modifier.fillMaxSize(),
                        contentScale=androidx.compose.ui.layout.ContentScale.Crop)
                    else Icon(Icons.Default.Movie,null,tint=PurpleBright,modifier=Modifier.size(36.dp))
                    Text(formatDuration(video.durationMs),color=Color.White,
                        modifier=Modifier.align(Alignment.BottomEnd).padding(5.dp)
                            .background(Color.Black.copy(alpha=.7f),RoundedCornerShape(5.dp))
                            .padding(horizontal=5.dp,vertical=2.dp),fontSize=10.sp)
                    if (selectionMode) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onToggleSelection() },
                            modifier = Modifier.align(Alignment.TopEnd).padding(2.dp)
                                .background(Color.Black.copy(alpha=.55f), RoundedCornerShape(8.dp))
                        )
                    } else {
                        IconButton(onClick=onToggleFavorite,modifier=Modifier.align(Alignment.TopEnd).padding(2.dp)
                            .background(Color.Black.copy(alpha=.48f),RoundedCornerShape(50)).size(34.dp)) {
                            Icon(if(isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                if(isFavorite) "Remove from favourites" else "Add to favourites",
                                tint=if(isFavorite) Color(0xFFFF5C8A) else Color.White)
                        }
                    }
                }
                Text(video.name,color=textColor,modifier=Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=10.dp),
                    maxLines=2,overflow=TextOverflow.Ellipsis,fontSize=13.sp,lineHeight=17.sp,fontWeight=FontWeight.SemiBold)
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun FullscreenPlayer(
    player: MediaController,
    onClose: () -> Unit,
    subtitleSizeSp: Float,
    subtitleColorName: String,
    subtitleBottomPadding: Float
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val originalBrightness = remember(activity) { activity?.window?.attributes?.screenBrightness ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
    DisposableEffect(activity) {
        onDispose {
            activity?.window?.let { window ->
                val params = window.attributes
                params.screenBrightness = originalBrightness
                window.attributes = params
            }
        }
    }
    var gestureHint by remember { mutableStateOf("Double tap sides to seek • swipe to adjust • ♪ audio tracks") }
    var hudLabel by remember { mutableStateOf("Brightness") }
    var hudPercent by remember { mutableIntStateOf(50) }
    var showGestureHud by remember { mutableStateOf(false) }
    var tapSeekLabel by remember { mutableStateOf("") }
    var showTapSeek by remember { mutableStateOf(false) }

    LaunchedEffect(showTapSeek, tapSeekLabel) {
        if (showTapSeek) {
            delay(850)
            showTapSeek = false
        }
    }

    LaunchedEffect(showGestureHud, hudLabel, hudPercent) {
        if (showGestureHud) {
            delay(1200)
            showGestureHud = false
        }
    }
    var locked by remember { mutableStateOf(false) }
    var showSpeedMenu by remember { mutableStateOf(false) }
    val playbackPrefs = remember {
        context.getSharedPreferences("arnit_playback_preferences", Context.MODE_PRIVATE)
    }
    var selectedSpeed by remember { mutableFloatStateOf(playbackPrefs.getFloat("speed", 1.0f)) }
    var repeatMode by remember { mutableIntStateOf(playbackPrefs.getInt("repeat_mode", Player.REPEAT_MODE_OFF)) }
    var shuffleEnabled by remember { mutableStateOf(playbackPrefs.getBoolean("shuffle_enabled", false)) }
    var resizeMode by remember { mutableIntStateOf(playbackPrefs.getInt("resize_mode", androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT)) }
    var showAspectMenu by remember { mutableStateOf(false) }
    var showQueueDialog by remember { mutableStateOf(false) }
    var showAudioTrackDialog by remember { mutableStateOf(false) }
    var audioTrackChoices by remember { mutableStateOf<List<Pair<Tracks.Group, Int>>>(emptyList()) }

    LaunchedEffect(player) {
        runCatching {
            player.setPlaybackSpeed(selectedSpeed)
            player.repeatMode = repeatMode
            player.shuffleModeEnabled = shuffleEnabled
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(player, locked) {
                if (!locked) {
                    detectTapGestures(
                        onDoubleTap = { offset ->
                            if (player.currentMediaItem != null) {
                                val duration = player.duration
                                val forward = offset.x >= size.width / 2f
                                val delta = if (forward) 10_000L else -10_000L
                                val proposed = (player.currentPosition + delta).coerceAtLeast(0L)
                                val target = if (duration > 0) proposed.coerceAtMost(duration) else proposed
                                player.seekTo(target)
                                tapSeekLabel = if (forward) "+10 seconds" else "-10 seconds"
                                showTapSeek = true
                            }
                        }
                    )
                }
            }
            .pointerInput(player, locked, activity) {
                if (!locked) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        if (kotlin.math.abs(drag.x) > kotlin.math.abs(drag.y)) {
                            val delta = if (drag.x > 0) 10_000L else -10_000L
                            val duration = player.duration
                            val proposed = (player.currentPosition + delta).coerceAtLeast(0L)
                            val target = if (duration > 0) proposed.coerceAtMost(duration) else proposed
                            player.seekTo(target)
                            gestureHint = if (delta > 0) "Forward 10 seconds" else "Back 10 seconds"
                        } else {
                            val leftHalf = change.position.x < size.width / 2f
                            if (leftHalf && activity != null) {
                                val current = activity.window.attributes.screenBrightness
                                    .takeIf { it >= 0f } ?: 0.5f
                                val next = (current - drag.y / size.height).coerceIn(0.05f, 1f)
                                val params = activity.window.attributes
                                params.screenBrightness = next
                                activity.window.attributes = params
                                hudLabel = "Brightness"
                                hudPercent = (next * 100).toInt()
                                showGestureHud = true
                                gestureHint = "Brightness $hudPercent%"
                            } else {
                                val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                val step = if (drag.y < 0) 1 else -1
                                val updated = (current + step).coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, updated, 0)
                                hudLabel = "Volume"
                                hudPercent = if (maxVolume > 0) (updated * 100f / maxVolume).toInt() else 0
                                showGestureHud = true
                                gestureHint = "Volume $hudPercent%"
                            }
                        }
                    }
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = !locked
                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    applySubtitleStyle(this, subtitleSizeSp, subtitleColorName, subtitleBottomPadding)
                }
            },
            update = {
                it.player = player
                applySubtitleStyle(it, subtitleSizeSp, subtitleColorName, subtitleBottomPadding)
                it.useController = !locked
            },
            modifier = Modifier.fillMaxSize()
        )
        if (player.currentMediaItem == null) {
            Column(
                modifier = Modifier.align(Alignment.Center)
                    .padding(horizontal = 28.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF28143F), Color(0xFF100B19), Color(0xFF4C247A))))
                    .padding(horizontal = 30.dp, vertical = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.PlayCircle, "Arnit Cinema", tint = PurpleBright, modifier = Modifier.size(76.dp))
                Text("ARNIT CINEMA", color = Color.White, letterSpacing = 4.sp, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("Choose a video to begin", color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.bodyMedium)
                Text("Open a video from your library to start playback", color = Color.White.copy(alpha = 0.62f), fontSize = 12.sp)
            }
        }
        if (showTapSeek && !locked && player.currentMediaItem != null) {
            Row(
                modifier = Modifier
                    .align(if (tapSeekLabel.startsWith("+")) Alignment.CenterEnd else Alignment.CenterStart)
                    .padding(horizontal = 26.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    if (tapSeekLabel.startsWith("+")) Icons.Default.FastForward else Icons.Default.FastRewind,
                    contentDescription = null,
                    tint = Color.White
                )
                Text(tapSeekLabel, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        if (showGestureHud && !locked && player.currentMediaItem != null) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 88.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = if (hudLabel == "Brightness") Icons.Default.Brightness6 else Icons.Default.VolumeUp,
                    contentDescription = hudLabel,
                    tint = Color.White
                )
                Column(modifier = Modifier.width(142.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("$hudLabel  $hudPercent%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.25f))) {
                        Box(Modifier.fillMaxWidth(hudPercent.coerceIn(0, 100) / 100f).fillMaxHeight().clip(RoundedCornerShape(50)).background(PurpleBright))
                    }
                }
            }
        }

        Row(
            Modifier.align(Alignment.TopEnd).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!locked && player.currentMediaItem != null) {
                Text(gestureHint, color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
                IconButton(onClick = { showQueueDialog = true }) {
                    Icon(Icons.Default.QueueMusic, "Playlist queue", tint = Color.White)
                }
                IconButton(onClick = {
                    repeatMode = when (repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                    player.repeatMode = repeatMode
                    playbackPrefs.edit().putInt("repeat_mode", repeatMode).apply()
                }) {
                    Icon(
                        when (repeatMode) {
                            Player.REPEAT_MODE_ALL -> Icons.Default.Repeat
                            Player.REPEAT_MODE_ONE -> Icons.Default.RepeatOne
                            else -> Icons.Default.Repeat
                        },
                        contentDescription = "Repeat mode",
                        tint = if (repeatMode == Player.REPEAT_MODE_OFF) Color.White else PurpleBright
                    )
                }
                IconButton(onClick = {
                    shuffleEnabled = !shuffleEnabled
                    player.shuffleModeEnabled = shuffleEnabled
                    playbackPrefs.edit().putBoolean("shuffle_enabled", shuffleEnabled).apply()
                }) {
                    Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffleEnabled) PurpleBright else Color.White)
                }
                IconButton(onClick = {
                    audioTrackChoices = player.currentTracks.groups
                        .filter { it.type == C.TRACK_TYPE_AUDIO }
                        .flatMap { group ->
                            (0 until group.length)
                                .filter { index -> group.isTrackSupported(index) }
                                .map { index -> group to index }
                        }
                    showAudioTrackDialog = true
                }) {
                    Icon(Icons.Default.MusicNote, "Audio track options", tint = Color.White)
                }
                IconButton(onClick = {
                    runCatching {
                        TrackSelectionDialogBuilder(context, "Subtitle track", player, C.TRACK_TYPE_TEXT).build().show()
                    }
                }) {
                    Icon(Icons.Default.Subtitles, "Select subtitle track", tint = Color.White)
                }
                Box {
                    TextButton(onClick = { showAspectMenu = true }) {
                        Text("AR", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(expanded = showAspectMenu, onDismissRequest = { showAspectMenu = false }) {
                        listOf(
                            "Fit" to androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT,
                            "Fill" to androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL,
                            "Zoom" to androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
                            "Fixed width" to androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
                            "Fixed height" to androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
                        ).forEach { (label, mode) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = {
                                resizeMode = mode
                                playbackPrefs.edit().putInt("resize_mode", mode).apply()
                                showAspectMenu = false
                            })
                        }
                    }
                }
                Box {
                    TextButton(onClick = { showSpeedMenu = true }) {
                        Text("${selectedSpeed}x", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(expanded = showSpeedMenu, onDismissRequest = { showSpeedMenu = false }) {
                        listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f, 4.0f).forEach { speed ->
                            DropdownMenuItem(text = { Text("${speed}x") }, onClick = {
                                selectedSpeed = speed
                                player.setPlaybackSpeed(speed)
                                playbackPrefs.edit().putFloat("speed", speed).apply()
                                showSpeedMenu = false
                            })
                        }
                    }
                }
            }
            if (player.currentMediaItem != null) {
                IconButton(onClick = { locked = !locked }) {
                    Icon(
                        if (locked) Icons.Default.Lock else Icons.Default.LockOpen,
                        if (locked) "Unlock controls" else "Lock controls",
                        tint = Color.White
                    )
                }
            }
            if (!locked) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.CloseFullscreen, "Exit fullscreen", tint = Color.White)
                }
            }
        }
        if (showAudioTrackDialog) {
            AlertDialog(
                onDismissRequest = { showAudioTrackDialog = false },
                title = { Text("Audio track") },
                text = {
                    Column(
                        modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "Choose the audio language or track for this video.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(
                            onClick = {
                                player.trackSelectionParameters = player.trackSelectionParameters
                                    .buildUpon()
                                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                    .build()
                                showAudioTrackDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AutoAwesome, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Auto select")
                        }
                        if (audioTrackChoices.isEmpty()) {
                            Text(
                                "No selectable audio tracks were found. This video may not have audio, or its audio track may not be supported.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            audioTrackChoices.forEachIndexed { rowIndex, choice ->
                                val group = choice.first
                                val trackIndex = choice.second
                                val format = group.mediaTrackGroup.getFormat(trackIndex)
                                val language = format.language?.takeIf { it.isNotBlank() } ?: "Unknown language"
                                val label = format.label?.takeIf { it.isNotBlank() }
                                val codec = format.sampleMimeType?.substringAfter("/") ?: "Audio"
                                val channels = if (format.channelCount > 0) "${format.channelCount} ch" else ""
                                val title = label ?: language.replaceFirstChar { it.uppercase() }
                                val detail = listOf(language, codec, channels).filter { it.isNotBlank() }.distinct().joinToString(" • ")
                                val selected = group.isTrackSelected(trackIndex)
                                TextButton(
                                    onClick = {
                                        player.trackSelectionParameters = player.trackSelectionParameters
                                            .buildUpon()
                                            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                            .addOverride(
                                                TrackSelectionOverride(
                                                    group.mediaTrackGroup,
                                                    listOf(trackIndex)
                                                )
                                            )
                                            .build()
                                        showAudioTrackDialog = false
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        if (selected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                        null,
                                        tint = if (selected) Purple else MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAudioTrackDialog = false }) { Text("Close") }
                }
            )
        }

        if (showQueueDialog) {
            AlertDialog(
                onDismissRequest = { showQueueDialog = false },
                title = { Text("Playback queue") },
                text = {
                    Column(
                        modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (player.mediaItemCount == 0) {
                            Text("No videos in the queue.")
                        } else {
                            (0 until player.mediaItemCount).forEach { index ->
                                val item = player.getMediaItemAt(index)
                                val itemTitle = item.mediaMetadata.title?.toString()
                                    ?: item.localConfiguration?.uri?.lastPathSegment
                                    ?: "Video ${index + 1}"
                                TextButton(
                                    onClick = {
                                        player.seekToDefaultPosition(index)
                                        player.play()
                                        showQueueDialog = false
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        if (index == player.currentMediaItemIndex) Icons.Default.PlayArrow else Icons.Default.VideoLibrary,
                                        null
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(itemTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showQueueDialog = false }) { Text("Close") }
                }
            )
        }
        if (locked && player.currentMediaItem != null) {
            IconButton(
                onClick = { locked = false },
                modifier = Modifier.align(Alignment.Center)
                    .background(Color.Black.copy(alpha = .55f), RoundedCornerShape(50))
            ) {
                Icon(Icons.Default.LockOpen, "Unlock player", tint = Color.White)
            }
        }
    }
}
